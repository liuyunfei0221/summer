如果你是基于本机开发并且你刚刚搭建/kafka时已经启动了zk环境,那么你可以忽略以下的内容.


1.将summer-env\seata-env\zk_seata-env中的apache-zookeeper-3.7.0-bin.tar.gz复制到你期望的目录中,并解压.

2.将apache-zookeeper-3.7.0-bin\conf中的zoo-simple.cfg重命名为zoo.cfg,并根据你的环境及需要配置zoo.cfg.

3.双击apache-zookeeper-3.7.0-bin\bin文件夹中的zkServer.cmd启动zookeeper.


另:如果是基于本地开发,你可以与kafka等其他中间件公用一套zk,但如果在生产环境,你需要考虑服务或组件间的舱壁隔离,防止故障扩散.