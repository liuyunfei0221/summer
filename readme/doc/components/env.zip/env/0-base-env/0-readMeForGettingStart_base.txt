1.安装IDE,jdk,maven等并配置环境变量.
