1.复制summer-env\6-es-env文件夹中的elasticsearch-7.14.x-windows-x86_64.zip文件到你期望的安装目录并解压.

2.在elasticsearch-7.14.x\plugins文件夹中新建analysis-ik文件夹,将summer-env\6-es-env文件夹中的elasticsearch-analysis-ik-7.14.x.zip文件复制到此处并解压.

3.双击elasticsearch-7.14.x\bin文件夹中的elasticsearch.bat文件启动es.