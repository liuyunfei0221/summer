1.将summer-env\zk-env中的apache-zookeeper-3.7.0-bin.tar.gz复制到你期望的目录中,并解压.

2.将apache-zookeeper-3.7.0-bin\conf中的zoo-simple.cfg重命名为zoo.cfg,并根据你的环境及需要配置zoo.cfg.

3.双击apache-zookeeper-3.7.0-bin\bin文件夹中的zkServer.cmd启动zookeeper.

请自行修改dubbo及seata所涉及的zk配置